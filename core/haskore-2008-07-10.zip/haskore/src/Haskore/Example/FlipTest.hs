module Main where

import qualified Flip
import qualified Haskore.Interface.MIDI.Render as RenderMidi
import qualified Sound.MIDI.File.Save   as SaveMidi

main :: IO ()
main =
   putStr (SaveMidi.openMidiFileToString
      (RenderMidi.testMixedMidi Flip.song))
