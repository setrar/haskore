{- |
This timer doesn't wait but returns immediately.
This is useful for turning real-time processing to non-real-time processing.
-}
module Haskore.Basic.Timer.Immediate (timer) where

import qualified Haskore.Basic.Timer as Timer
import System.Time(ClockTime(TOD))

import qualified Numeric.NonNegative.Wrapper as NonNeg


timer :: Timer.T
timer = Timer.Cons getClockTime wait resolution

getClockTime :: IO ClockTime
getClockTime = return $ TOD 0 0

{- |
Wait the given number of @(recip resolution)@ seconds.
-}
wait :: NonNeg.Int -> IO ()
wait _ = return ()

resolution :: Num a => a
resolution = 50
