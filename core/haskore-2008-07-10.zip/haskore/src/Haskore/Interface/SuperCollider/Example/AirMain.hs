module Main where

import qualified Haskore.Interface.SuperCollider.Example.Air as Air

main :: IO ()
main = Air.main
